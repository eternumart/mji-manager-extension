/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/**
 * Content script-мост между попапом (целевая страница) и background расширения.
 * Попап может не иметь доступа к chrome.* (контекст страницы), с сайта нельзя делать fetch из-за CORS.
 * Все запросы к API идут через background; попап общается с background через этот мост:
 * попап -> window.postMessage -> bridge (content script) -> chrome.runtime.sendMessage -> background.
 * Ответы: background -> chrome.runtime.sendMessage -> bridge -> window.postMessage -> попап.
 */const MJI_EXTENSION_REQUEST="MJI_EXTENSION_REQUEST";const MJI_EXTENSION_RESPONSE="MJI_EXTENSION_RESPONSE";function isFromPage(ev){try{var _ev$data,_ev$data2;return((_ev$data=ev.data)===null||_ev$data===void 0?void 0:_ev$data.type)===MJI_EXTENSION_REQUEST&&((_ev$data2=ev.data)===null||_ev$data2===void 0?void 0:_ev$data2.payload)!=null;}catch{return false;}}// Запросы от страницы/попапа — пересылаем в background.
// Для UPLOAD_PDF держим порт открытым, чтобы service worker не засыпал во время долгого запроса.
window.addEventListener("message",ev=>{if(!isFromPage(ev))return;const payload=ev.data.payload;const isPdfUpload=(payload===null||payload===void 0?void 0:payload.type)==="UPLOAD_PDF";let keepAlivePort=null;if(isPdfUpload){keepAlivePort=chrome.runtime.connect({name:"pdf-upload"});}chrome.runtime.sendMessage(payload).catch(err=>{if(keepAlivePort)keepAlivePort.disconnect();console.warn("[MJI bridge] sendMessage error:",err);window.postMessage({type:MJI_EXTENSION_RESPONSE,payload:{type:(payload===null||payload===void 0?void 0:payload.type)+"_RESPONSE"||0,error:String(err)}},"*");});// Порт закроет background после доставки результата (onConnect в DOMEvaluator).
});// Ответы от background — пересылаем на страницу (попап без доступа к chrome получит через window message)
chrome.runtime.onMessage.addListener(message=>{const forwardTypes=["REPHRASE_DEFECTS_BLOCK_RESPONSE","UPLOAD_COMPLETE","UPLOAD_FAILED"];if(message&&forwardTypes.includes(message.type)){window.postMessage({type:MJI_EXTENSION_RESPONSE,payload:message},"*");}});console.log("[MJI] bridge content script загружен");
/******/ })()
;