export const UpdateLink = () => {
	return (
		<a className='update' href='https://github.com/eternumart/Chrome-App/raw/dev/App/Chrome-App.exe' target='_blank' rel="noreferrer">
			Скачать последнюю версию
		</a>
	);
};
